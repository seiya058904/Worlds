# 新轮回方案索引（有效）

|索引|有效文件|旧文件状态|
|---|---|---|
|总设定|`01-foundation/reincarnation-core.md`|`premise.md`、`systems-and-rules.md`、`theme.md`中的命债内容失效。|
|人物|`01-foundation/reincarnation-characters.md`|`characters.md`、`relationships.md`为旧方案历史材料。|
|人生|`02-story-plan/reincarnation-lives.md`|旧五段人生方案失效。|
|总纲|`02-story-plan/reincarnation-master-outline.md`|`master-outline.md`失效。|
|时间线|`05-continuity/reincarnation-timeline.md`|`05-continuity/timeline.md`失效。|
|伏笔|`02-story-plan/reincarnation-foreshadowing.md`|`foreshadowing.md`失效。|
|爽点|`02-story-plan/reincarnation-payoff-map.md`|`payoff-map.md`失效。|
|章节|`02-story-plan/reincarnation-chapter-outline.md`|`chapter-outline.md`失效。|
|审计|`06-review/reincarnation-rebuild-audit.md`|旧红队/开稿审计仅供历史追踪。|

所有旧命债相关材料仅用于历史追踪，不得作为当前写作依据。
