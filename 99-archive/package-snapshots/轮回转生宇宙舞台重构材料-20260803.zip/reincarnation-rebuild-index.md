# 新轮回方案索引（有效）

|索引|有效文件|旧文件状态|
|---|---|---|
|总设定|`01-foundation/reincarnation-core.md`|`premise.md`、`systems-and-rules.md`、`theme.md`中的命债内容失效。|
|人物|`01-foundation/reincarnation-characters.md`|`characters.md`、`relationships.md`为旧方案历史材料。|
|人生|`02-story-plan/reincarnation-lives.md`|旧五段人生方案失效。|
|唯一轮回顺序（P0事实源）|`05-continuity/unique-reincarnation-sequence.md`|其他文件不得另设人生先后、年份或章节范围。|
|总纲|`02-story-plan/reincarnation-master-outline.md`|`master-outline.md`失效。|
|时间线|`05-continuity/reincarnation-timeline.md`|`05-continuity/timeline.md`失效。|
|伏笔|`02-story-plan/reincarnation-foreshadowing.md`|`foreshadowing.md`失效。|
|爽点|`02-story-plan/reincarnation-payoff-map.md`|`payoff-map.md`失效。|
|章节|`02-story-plan/reincarnation-chapter-outline.md`|`chapter-outline.md`失效。|
|审计|`06-review/reincarnation-rebuild-audit.md`|旧红队/开稿审计仅供历史追踪。|
|宇宙层级提案|`06-review/reincarnation-cosmic-hierarchy-proposal.md`|已批准并已下放至本轮重构。|
|宇宙大历史轴|`05-continuity/reincarnation-grand-chronology.md`|本轮重构的时间事实源。|
|感情矩阵|`01-foundation/reincarnation-romance-matrix.md`|4位最终稳定伴侣及跨世关系。|
|势力关系|`01-foundation/reincarnation-factions.md`|地方至宇宙级势力关系。|
|力量与宇宙地图|`02-story-plan/reincarnation-power-and-cosmos-map.md`|八卷地图、境界、身份曲线。|
|参考应用门禁|`03-writing-standard/reference-application-protocol.md`、`05-continuity/reference-application-log.md`|旧方案未设置的正文强制复核流程。|
|参考03深读|`06-review/reference03-commercial-deep-study.md`|以抽象升级、爽点、对话与关系规律校准正文。|

所有旧命债相关材料仅用于历史追踪，不得作为当前写作依据。
